/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

import java.util.ArrayList;

import java.util.List;

/**
 *
 * @author pc tech
 */
public class StudentHelper {
   
   
   public List<Student> listofStudents()
   {
    List<Student> list=new ArrayList<>();
    Student s1=new Student(1, "suhas", "MBA", "male", 22);
    Student s2=new Student(2, "subhash", "MCA", "male", 23);
    Student s3=new Student(3, "sumithra", "MBBS", "female", 24);
    Student s4=new Student(4, "shalini", "M.COM", "female", 25);
    Student s5=new Student(5, "sharath", "M.TECH", "male", 26);
    list.add(s1);
    list.add(s2);
    list.add(s3);
    list.add(s4);
    list.add(s5);
    
   return list;
    }
    public static void main(String[] args) 
    {
        StudentHelper s=new StudentHelper();
        List<Student> list=new ArrayList<>();
        System.out.println(s.listofStudents());
        
             
        
    }
}
