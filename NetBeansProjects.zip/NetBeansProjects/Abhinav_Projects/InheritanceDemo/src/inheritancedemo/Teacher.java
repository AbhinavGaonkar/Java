/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritancedemo;

/**
 *
 * @author pc tech
 */
public class Teacher extends Person{
    private String subject;
    Teacher(int id,String name,String subject){
        super(id,name);
        this.subject=subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    protected String print_state() {
        return super.print_state()+" "+getSubject(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
