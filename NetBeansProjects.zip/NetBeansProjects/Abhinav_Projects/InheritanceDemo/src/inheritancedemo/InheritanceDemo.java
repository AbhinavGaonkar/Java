/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritancedemo;

/**
 *
 * @author pc tech
 */
public class InheritanceDemo {

    public static void main(String[] args) {
        Person p=new Person(1,"Abhinav");
        Student s=new Student(2,"Abhi","Java");
        Peon pe=new Peon(3,"Abhishek","MCA");
        Teacher t=new Teacher(4,"Yogi","Java");
        
        System.out.println("Person : "+p.print_state()+"\nStudent : "+s.print_state()+"\nPeon : "+pe.print_state()+"\nTeacher : "+t.print_state());
        
        
        // TODO code application logic here
    }
    
}
