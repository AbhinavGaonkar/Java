/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritancedemo;

/**
 *
 * @author pc tech
 */
public class Student extends Person {
    private String course_taken;
    Student(int id,String name,String course){
        super(id,name);
        this.course_taken=course;
    } 

    public String getCourse_taken() {
        return course_taken;
    }

    public void setCourse_taken(String course_taken) {
        this.course_taken = course_taken;
    }

    @Override
    protected String print_state() {
        return super.print_state()+" "+getCourse_taken(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
