/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritancedemo;

/**
 *
 * @author pc tech
 */
public class Peon extends Person{
    private String department;
    Peon(int id,String name,String Dept)
    {
        super(id,name);
        this.department=Dept;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    protected String print_state() {
        return super.print_state()+" "+getDepartment(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
