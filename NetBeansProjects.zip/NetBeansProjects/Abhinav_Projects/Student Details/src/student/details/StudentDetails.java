
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student.details;
import java.io.*;
/**
 *
 * @author pc tech
 */
public class StudentDetails {
       private int id;
       private String name;
       private String course;
       private Long mobile_number;
       private int rollno;
       static int nextrollno=1000;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourse() {
        return course;
    }
 
    public void setCourse(String course) {
        this.course = course;
    }

    public Long getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(Long mobile_number) {
        this.mobile_number = mobile_number;
    }

    public StudentDetails(int id, String name, String course, long mobile_number) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.mobile_number = mobile_number;
        this.rollno= nextrollno++;
    }
        public String toString(){//overriding the toString() method  
           return id+" "+name+" "+course+" "+mobile_number+" "+rollno;  
 }  
    
    /**
     * 
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            StudentDetails s1=new StudentDetails(101,"Abhinav","MCA",123456);
            StudentDetails s2=new StudentDetails(102,"Karan","MCA",654321);
            StudentDetails s3=new StudentDetails(103,"Rohan","MCA",654321);
            System.out.println(s1);
            System.out.println(s2);
            System.out.println(s3);
            
        
    }
    
}
