/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardetails;

/**
 *
 * @author pc tech
 */
public class CarDetails {

    private int EngineNumber;
    static int NextEngineNumber=100;
    private String CarVendor;
    private int ChassisNumber;
    static int NextChassisNumber=2000;

    public int getEngineNumber() {
        return EngineNumber;
    }

    public void setEngineNumber(int EngineNumber) {
        this.EngineNumber = EngineNumber;
    }

    public String getCarVendor() {
        return CarVendor;
    }

    public void setCarVendor(String CarVendor) {
        this.CarVendor = CarVendor;
    }

    public int getChassisNumber() {
        return ChassisNumber;
    }

    public void setChassisNumber(int ChassisNumber) {
        this.ChassisNumber = ChassisNumber;
    }

    public CarDetails(String CarVendor) {
        EngineNumber = NextEngineNumber++;
        this.CarVendor = CarVendor;
        ChassisNumber=NextChassisNumber++;
    }
    
    public String toString(){
        return EngineNumber+" "+CarVendor+" "+ChassisNumber;
    }
    
    
   
    
}
