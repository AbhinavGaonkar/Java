/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardetails;

/**
 *
 * @author pc tech
 */
public class MainClass {
     public static void main(String[] args) {
       CarDetails car1=new CarDetails("Suzuki");
       CarDetails car2=new CarDetails("Honda");
       CarDetails car3=new CarDetails("Hyundai");
       System.out.println(car1);
       System.out.println(car2);
       System.out.println(car3);
       
    }
}
