/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraydemo;

import java.io.*;
import java.util.*;

/**
 *
 * @author pc tech
 */
public class ArrayDemo {

    protected int[] arr = new int[5];

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayDemo a = new ArrayDemo();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array elements\n");
        for (int i = 0; i < a.arr.length; i++) {
            a.arr[i] = sc.nextInt();
        }
        System.out.println("\n The array elements are\n");
        for (int i = 0; i < a.arr.length; i++) {
            System.out.println(a.arr[i] + "\n");
        }

    }

}
