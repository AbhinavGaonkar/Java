/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enumdemo;

/**
 *
 * @author pc tech
 */
public enum Enum{SWIFT(1),I20(2),FIGO(3),POLO(4);
    private int value;
    private Enum(int value){  
    this.value=value;  
}  

    
    public static void main(String[] args) {
        for (Enum s:Enum.values())
        {
            System.out.println(s+" "+s.value);
        }
    }
    
}