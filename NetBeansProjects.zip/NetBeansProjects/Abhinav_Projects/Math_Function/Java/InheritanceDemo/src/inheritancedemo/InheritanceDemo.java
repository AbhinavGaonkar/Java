
package inheritancedemo;


public class InheritanceDemo {

    public static void main(String[] args) {
         
    }
    
}
