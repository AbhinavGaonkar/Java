package math_function;
import java.util.*;

public class Math_Function 
{
	public int ADD(int a,int b)
	{
		int c;
		c=a+b;
		return c;
		
	}
	public int SUBTRACT(int a,int b)
	{
		int c=0;
		c=a-b;
		return c;
	}
	public int MULTIPLY(int a,int b)
	{
		int c=0;
		c=a*b;
		return c;
	}
	public double DIVIDE(int a,int b)
	{
		double c=0.0;
		c=a/b;
		return c;
	}
		
	

	public static void main(String args[])
	{
		int ch=0;
		int d=0,e=0;
		Math_Function mf=new Math_Function();
		Scanner in=new Scanner(System.in);
		do
		{
		
		System.out.println("Enter the numbers");
		d =in.nextInt();
		e =in.nextInt();
		
		System.out.println("Enter the type of function \n 1.Add 2.Subtract 3.Multiply 4.Divide 5.Exit");
		ch=in.nextInt();
		switch(ch)
		{
			case 1 : System.out.println("Answer is " + mf.ADD(d,e));
					break;
					
			case 2 : System.out.println("Answer is " + mf.SUBTRACT(d, e));
					break;
			
			case 3 : System.out.println("Answer is " + mf.MULTIPLY(d, e));
					break;
				
			case 4 : System.out.println("Answer is " + mf.DIVIDE(d, e));
			        break;
			case 5 : System.exit(0);
					break;
		}
		}while(ch!=5);
		
		
	}
}